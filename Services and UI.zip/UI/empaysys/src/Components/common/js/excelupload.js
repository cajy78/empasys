import axios from "axios";
import React from "react";
import * as XLSX from "xlsx";
import '../css/excelupload.css';

export default class ExcelUpload extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            fileToUpload:null,
            uploadingStatusText:"",
            showUploading:false
        };

        this.uploadProjectDetails = this.uploadProjectDetails.bind(this);
        this.callUploadFunction = this.callUploadFunction.bind(this);
        this.uploadMonthlyAttendance = this.uploadMonthlyAttendance.bind(this);
    }

    uploadMonthlyAttendance = ()=>{
        this.readExeclFile().then((result)=>{

            var jsonDataToSend = [];

            //loop through each emp attendance values found in the excel
            for(var i=0;i<result.length;i++){

                //get the unique dates for the line item
                var dates = Object.keys(result[i]);
                
                //loop through all the dates of the attendance values found in the excel
                for(var j=3; j<dates.length;j++){
                    
                    //dont add attendace value of the dates with no data in them.
                    if(result[i][dates[j]]==undefined)
                    {
                        //if such a line item is hit then continue the loop
                        continue;
                    }

                    //add the data to the json data to be sent to the server
                    jsonDataToSend.push({
                        "empnumber": result[i].empid,
                        "projectname": result[i].Type,
                        "date":dates[j],
                        "attendanceStatus":result[i][dates[j]]
                    });
                }
            }

            this.uploadToServer('http://localhost:2001/bulkuploadattendance',jsonDataToSend);

            //code to download excel file
            //var newws = XLSX.utils.json_to_sheet(result);
            //var newwb = XLSX.utils.book_new();
            //XLSX.utils.book_append_sheet(newwb,newws,"madness");
            //XLSX.writeFile(newwb, "sheetjs.xlsx");
        }).catch((err)=>{
            console.log(err);
            this.setState({
                uploadingStatusText:err
            });
        });
    }

    uploadProjectDetails = ()=>{
        
        this.readExeclFile().then((result)=>{
            this.uploadToServer('http://localhost:2001/bulkuploadprojectdetails',result);
        }).catch((err)=>{
            console.log(err);
            this.setState({
                showUploading:false,
                uploadingStatusText:err
            });
        });
    }

    readExeclFile=()=>{
        return new Promise((resolve, reject)=>{
            try{
                const [file] = this.state.fileToUpload.target.files;
                const reader = new FileReader();

                reader.onload=(evt)=>{
                    const bstr = evt.target.result;
                    const wb = XLSX.read(bstr, { type: "binary" });
                    const wsname = wb.SheetNames[0];
                    const ws = wb.Sheets[wsname];
                    const data = XLSX.utils.sheet_to_json(ws);
                    resolve(data);
                }

                reader.readAsBinaryString(file);
            }
            catch(err){
                reject(err);
            }
        });
    }

    callUploadFunction = ()=>{
        this.setState({
            showUploading:true,
            uploadingStatusText:"Uploading Please Wait..."
        });

        switch(this.props.uploadfunction){
            case "UploadProjectDetails":
                this.uploadProjectDetails();
                break;
            
            case "UploadMonthlyAttendance":
                this.uploadMonthlyAttendance();
                break;
        }
    }

    uploadToServer=(apiendpoint,result)=>{
        axios.post(apiendpoint,{"data":result},{
            headers:{
                "x-access-token":localStorage.getItem("auth")
            }})
        .then((response)=>{
            this.setState({
                showUploading:false,
                uploadingStatusText:"Uploading Completed" + response.data
            });
        }).catch((err)=>{
            if(err.response!=null){
                if(err.response.data=="Unauthorized"){
                    this.props.setunauthorizeduser();
                }
                console.log(err.response);
                this.setState({
                    showUploading:false,
                    uploadingStatusText:err.response.statusText
                });
            }
            else{
                console.log(err);
                this.setState({
                    showUploading:false,
                    uploadingStatusText:err + "\n Make sure you are connected to the network and try again \n If the issue still persists kindly get in touch with the administrator"
                });
            }
        });   
    }

    setFileEvent = (e)=>{
        this.setState({
            fileToUpload:e
        });
    }



    render(){
        return(
            <div className="card">
                <div className="card-body">
                    <div className="row">
                        <div>
                            <h6>{this.props.title}</h6>
                        </div>
                    </div>
                    <br/>
                    <div className="row">
                        <div className="col">
                            {!this.state.showUploading ?
                                <input type="file" className="form-control" onChange={this.setFileEvent}/>
                                :
                                <input type="file" disabled className="form-control" onChange={this.setFileEvent}/>
                            }
                        </div>
                    </div>
                    <br/>
                    <div className="row">
                        <div className="col">
                            <textarea readonly value={this.state.uploadingStatusText} className="form-control errorArea"/>
                        </div>
                    </div>
                    <br/>
                    <div className="row">
                        <div className="col">
                            {!this.state.showUploading ?
                                <button className="btn btn-outline-success btn-sm" onClick={this.callUploadFunction}>{this.props.buttonText}</button>
                                :
                                <button className="btn btn-outline-success btn-sm" onClick={this.callUploadFunction} disabled>Uploading Please wait...</button>
                            }
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}