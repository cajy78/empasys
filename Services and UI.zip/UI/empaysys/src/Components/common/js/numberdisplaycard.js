import React from "react";
import "../css/numberdisplaycard.css";

export default class NumberDisplayCards extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="maincard">
                <div className="uppercard">
                    <h2 style={{color:this.props.color}}>{this.props.number}</h2>
                </div>
                <div className="lowercard" style={{backgroundColor:this.props.color, color:this.props.displayTextColor}}>
                    <span>{this.props.displaytext}</span>
                </div>
            </div>
        );
    }
}