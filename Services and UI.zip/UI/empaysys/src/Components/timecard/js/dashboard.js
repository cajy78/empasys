import React from "react";
import NumberDisplayCards from "../../common/js/numberdisplaycard";
import "../css/dashboard.css";
import FullCalendar from '@fullcalendar/react' // must go before plugins
import dayGridPlugin from '@fullcalendar/daygrid' // a plugin!
import axios from "axios";

export default class TimecardDashboard extends React.Component{
    constructor(props){
        super(props);
        this.state={
            presentDays:0,
            leaves:0,
            overtime:0,
            eidHolidays:0
        }
        this.loadEventOnCalChange = this.loadEventOnCalChange.bind();
    }

    loadEventOnCalChange = (fetchinfo, onsuccess, onfailure) =>{
        console.log(fetchinfo);
        var jsontosend = {
            startDate : fetchinfo.startStr.split('T')[0],
            endDate : fetchinfo.endStr.split('T')[0]
        };
        console.log(jsontosend);
        axios.post('http://localhost:2001/getmyattendanceforcalenderview',{"data":jsontosend},{
            headers:{
                "x-access-token":localStorage.getItem("auth")
            }})
            .then((resp)=>{
                console.log(resp.data);
                var pd = 0;
                var l = 0;
                var ot=0;
                var eih=0;
                onsuccess(Array.prototype.slice.call(resp.data).map((eventEl)=>{
                    
                    if(eventEl.project=="Overtime"){
                        ot+=eventEl.hours;
                    }
                    else{
                        switch (eventEl.status){
                            case "Present":
                                pd+=1;
                                break;
                            case "Leave":
                                l+=1;
                                break;
                            case "EIH":
                                eih+=1;
                                break;
                        }
                    }

                    this.setState({
                        presentDays: pd,
                        overtime:ot,
                        leaves:l,
                        eidHolidays:eih
                    });

                    return {
                        title: eventEl.event,
                        start: eventEl.start.split('T')[0],
                        allDay: true
                    }
                }));
            }).catch(err=>{
                onfailure(err);
            });
        //onsuccess(Array.prototype.slice.call(this.state.calEvent).map((eventEl)=>{
          //  return {
            //    title: eventEl.title,
              //  start: eventEl.start
              //}
        //}));
    }

    render(){
        return(
            <>
            <div className="numberdisplay">
                <div className="numberdisplayDiv">
                    <NumberDisplayCards color="#009E60" number={this.state.presentDays} displaytext="Days Present" displayTextColor="white"/>
                </div>
                <div className="numberdisplayDiv">
                    <NumberDisplayCards color="#5D3FD3" number={this.state.leaves} displaytext="Leaves" displayTextColor="white"/>
                </div>
                <div className="numberdisplayDiv">
                    <NumberDisplayCards color="#9F2B68" number={this.state.overtime} displaytext="Overtime" displayTextColor="white"/>
                </div>
                <div className="numberdisplayDiv">
                    <NumberDisplayCards color="#702963" number={this.state.eidHolidays} displaytext="Eid Holiday" displayTextColor="white"/>
                </div>
            </div>
            <div className="card calenderdisplay">
                <div className="row">
                    <div className="col">
                        Timecard Calender
                    </div>
                </div>
                <div className="row">
                    <FullCalendar
                        plugins={[ dayGridPlugin ]}
                        initialView="dayGridMonth"
                        headerToolbar={{
                            left: '',
                            center: 'title',
                            right: 'prev,next'
                          }}
                        events={this.loadEventOnCalChange}
                    />
                </div>
            </div>
            </>
        );
    };
}