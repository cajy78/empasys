import React from "react";
import ExcelUpload from '../../common/js/excelupload.js'

export default class UploadAttendance extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <ExcelUpload setunauthorizeduser={this.props.setunauthorizeduser} title="Upload Monthly Attendance" buttonText="Upload" uploadfunction="UploadMonthlyAttendance"/>
        );
    }
}