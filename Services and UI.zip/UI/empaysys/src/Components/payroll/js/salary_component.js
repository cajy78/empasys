import React from "react";
import axios from "axios";

export default class Salary_Component extends React.Component{
    constructor(props){
        super(props);
        this.state={
            componentName:'',
            displayInPayslip:1,
            displayIfZero:1,
            showInAddition:1,
            showInDeduction: 0,
            showUploading:false
        };
        this.addSalaryComponentNameChange=this.addSalaryComponentNameChange.bind();
        this.adddisplayInPayslipChange=this.adddisplayInPayslipChange.bind();
        this.adddisplayIfZeroChange=this.adddisplayIfZeroChange.bind();
        this.addComponent=this.addComponent.bind();
        this.addshowInAddtionChange=this.addshowInAddtionChange.bind();
        this.addshowInDeductionChange=this.addshowInDeductionChange.bind();
    }

    addSalaryComponentNameChange = (event)=>{
        this.setState({
            componentName:event.target.value
        });
    }

    adddisplayInPayslipChange = (event)=>{
        this.setState({
            displayInPayslip:event.target.value
        });
    }

    adddisplayIfZeroChange = (event)=>{
        this.setState({
            displayIfZero:event.target.value
        });
    }

    addshowInAddtionChange = (event)=>{
        this.setState({
            showInAddition:event.target.value
        });
    }

    addshowInDeductionChange = (event)=>{
        this.setState({
            showInDeduction:event.target.value
        });
    }

    addComponent = ()=>{
        this.uploadToServer('http://localhost:2002/addsalarycomponent',
        [{
            'name':this.state.componentName, 
            'displayInPayslip':this.state.displayInPayslip,
            'displayIfZero':this.state.displayIfZero,
            'showInAddition':this.state.showInAddition,
            'showInDeduction':this.state.showInDeduction
        }]);
    }

    getComponent=()=>{

    }

    uploadToServer=(apiendpoint,result)=>{
        axios.post(apiendpoint,{"data":result},{
            headers:{
                "x-access-token":localStorage.getItem("auth")
            }})
        .then((response)=>{
            this.setState({
                showUploading:false
            });
        }).catch((err)=>{
            if(err.response!=null){
                if(err.response.data=="Unauthorized"){
                    this.props.setunauthorizeduser();
                }
                console.log(err.response);
                this.setState({
                    showUploading:false
                });
            }
            else{
                console.log(err);
                this.setState({
                    showUploading:false
                });
            }
        });   
    }

    

    render(){
        return(
            <>
                <div className="card">
                    <div className="card-body">
                        <div className="row">
                            <h6>Add Salary Component</h6>
                            <div className="row">
                                <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Component Name</span>
                                        </div>
                                        <input type="text" className="form-control" onChange={this.addSalaryComponentNameChange} value={this.state.componentName} className="form-control" />
                                    </div>
                                <div className="row">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Display In Payslip</span>
                                        </div>
                                        <select className="form-control" onChange={this.adddisplayInPayslipChange}>
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Display If Zero</span>
                                        </div>
                                        <select className="form-control" onChange={this.adddisplayIfZeroChange}>
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Show in addition</span>
                                        </div>
                                        <select className="form-control" onChange={this.addshowInAddtionChange}>
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row">
                                    <div class="input-group mb-3">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon1">Show in Deductions</span>
                                        </div>
                                        <select className="form-control" onChange={this.addshowInDeductionChange}>
                                            <option value="1">Yes</option>
                                            <option value="0" selected>No</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row">
                                    <button class="btn btn-outline-success" onClick={this.addComponent}>Add</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        );
    }
}