import React from "react";
import axios from "axios";

export default class Add_Emp_Salary extends React.Component{
    constructor(props){
        super(props);
        this.state={
            empLst:[],
            salCompLst:[],
            showUploading:false
        }
        
        this.getSalaryComponents = this.getSalaryComponents.bind();
        this.getEmployees = this.getEmployees.bind();
    }

    componentDidMount(){
        this.getSalaryComponents();
        this.getEmployees();
    }

    getSalaryComponents=()=>{
        axios.post("http://localhost:2002/getsalarycomponent",{"data":""},{
            headers:{
                "x-access-token":localStorage.getItem("auth")
            }})
        .then((response)=>{
            var data = [];
            for(var i in response.data){
                data.push({"name":response.data[i].Name,"id":response.data[i].id,"amt":0});
            }
            this.setState({
                salCompLst:data
            });
        }).catch((err)=>{
            if(err.response!=null){
                if(err.response.data=="Unauthorized"){
                    this.props.setunauthorizeduser();
                }
                console.log(err.response);
                this.setState({
                    showUploading:false
                });
            }
            else{
                console.log(err);
                this.setState({
                    showUploading:false
                });
            }
        });   
    }

    getEmployees=()=>{
        axios.post("http://localhost:2003/getemployees",{"data":""},{
            headers:{
                "x-access-token":localStorage.getItem("auth")
            }})
        .then((response)=>{
            var data = [];
            for(var i in response.data){
                data.push({"name":response.data[i].FName+" "+response.data[i].MName+" "+response.data[i].LName,"id":response.data[i].id});
            }
            this.setState({
                empLst:data
            });
        }).catch((err)=>{
            if(err.response!=null){
                if(err.response.data=="Unauthorized"){
                    this.props.setunauthorizeduser();
                }
                console.log(err.response);
                this.setState({
                    showUploading:false
                });
            }
            else{
                console.log(err);
                this.setState({
                    showUploading:false
                });
            }
        });
    }

    selectEmpChange = (event)=>{
        var empID=event.target.value;
        axios.post("http://localhost:2002/getemployeessal",{"data":{'empid':empID}},{
            headers:{
                "x-access-token":localStorage.getItem("auth")
            }})
        .then((response)=>{
            var data = this.state.salCompLst;
            for(var i in response.data){
                data.push({"name":response.data[i].ComponentName,"id":response.data[i].componentID,"amt":response.data[i].amount});
            }
            this.setState({
                salCompLst:data
            });
        }).catch((err)=>{
            if(err.response!=null){
                if(err.response.data=="Unauthorized"){
                    this.props.setunauthorizeduser();
                }
                console.log(err.response);
                this.setState({
                    showUploading:false
                });
            }
            else{
                console.log(err);
                this.setState({
                    showUploading:false
                });
            }
        });
    }

    render(){
        return(
            <>
                <div className="row">
                    <div className="card">
                        <div className="card-body">
                            <div className="row">
                                Select Employee:
                                <select className="form-control">
                                    <option></option>
                                    {
                                        this.state.empLst.map((emp)=>{
                                            return <option key={emp.id} value={emp.id}>{emp.name}</option>
                                        })
                                    }
                                </select>
                            </div>
                            <br/>
                            <div className="row">
                                <table className="table table-bordered">
                                    <tbody>
                                        {
                                            this.state.salCompLst.map((salComp)=>{
                                                return <tr key={salComp.id}>
                                                    <td className="table-primary">{salComp.name}</td>
                                                    <td><input type='number' className="form-control" value={salComp.amt} /></td>
                                                </tr>
                                            })
                                        }
                                    </tbody>
                                </table>
                            </div>
                            <div className="row">
                                <input type="button" value="Save" className=" btn btn-outline-success"/>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        );
    }
}

