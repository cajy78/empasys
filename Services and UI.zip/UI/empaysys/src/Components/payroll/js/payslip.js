import React from "react";
import '../css/payslip.css'

export default class Payslip extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <>
                <div className="card">
                    <div className="card-body">
                        <div className="row">
                            <div className="col">
                                Details
                            </div>
                            <div className="col-3">
                                <select className="form-control">
                                    <option>Jan-2022</option>
                                    <option>Feb-2022</option>
                                    <option>Mar-2022</option>
                                </select>
                            </div>
                        </div>
                        <br/>
                        <div className="row">
                            <div className="col">
                                <table className="table table-bordered">
                                    <thead>
                                        <tr className="table-primary">
                                            <th scope="col" colSpan="2">Income</th>
                                            <th scope="col" colSpan="2">Deductions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td colSpan="2">
                                                <table className="table table-hover">
                                                    <tr>
                                                        <td>Basic Pay</td>
                                                        <td className="tablevlauestxt">100</td>
                                                    </tr>
                                                    <tr>
                                                        <td>House Allowance</td>
                                                        <td className="tablevlauestxt">100</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Other Allowance</td>
                                                        <td className="tablevlauestxt">1000</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Overtime</td>
                                                        <td className="tablevlauestxt">100</td>
                                                    </tr>
                                                    <tr>
                                                        <td>Other</td>
                                                        <td className="tablevlauestxt">100</td>
                                                    </tr>
                                                </table>
                                            </td>
                                            <td colSpan="2">
                                                <table className="table table-hover">
                                                    <tr>
                                                        <td>Other Deductions</td>
                                                        <td className="tablevlauestxt">2000</td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                        <tr className="table-info">
                                            <th>Total</th>
                                            <th className="totalvaluestxt">1000</th>
                                            <th>Total</th>
                                            <th className="totalvaluestxt">2000</th>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="row">
                            <div className="col downloadBtn">
                                <button className="btn btn-success">Download Payslip</button>
                            </div>
                        </div>
                    </div>
                </div>
            </>
        );
    }
}