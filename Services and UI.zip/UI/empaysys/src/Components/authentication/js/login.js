import React from 'react';
import '../css/login.css';
import error from '../images/error.png'
import axios from 'axios';

export default class Login extends React.Component{
    constructor(props) {
        super(props);
        this.state = { 
            loginID: '',
            password:'',
            loginLoader: false,
            showErrorBox:false,
            errorBoxText:'',
            showEmptyLoginIDInputError:false,
            showEmptyPasswordInputError:false,
            slientLogin:true
        };

        this.performLogin = this.performLogin.bind(this);
        this.validateToken = this.validateToken.bind(this);
      }
    
      componentDidMount(){
          if(this.props.isAuthHeadAvailable){
            this.validateToken();
          }
          else{
            this.setState({
                slientLogin:false
            });
          }
      }

      validateToken=()=>{
        axios.post('http://localhost:2000/validateToken',{},{
            headers:{
                "x-access-token":localStorage.getItem("auth")
            }
        }).then((result)=>{
            if(result.data.hasError){
                if(result.data.message.name=="TokenExpiredError"){
                    this.setState({
                        errorBoxText:"Session expired. Kindly login again",
                        showErrorBox:true,
                        slientLogin:false
                    });   
                }
                else{
                    this.setState({
                        errorBoxText:result.data.message.name,
                        showErrorBox:true,
                        slientLogin:false
                    });
                }
            }
            else{
                this.props.postAutherization(result.data.username);
            }
        })
        .catch((error)=>{
            this.setState({
                errorBoxText:error.toString(),
                showErrorBox:true,
                slientLogin:false
            });
        });
      }
    
    performLogin=()=>{
        var errorOccured=false;
        if(this.state.loginID.trim()==''|| this.state.loginID==null){
            errorOccured=true;
            this.setState({
                showEmptyLoginIDInputError:true
            });
        }

        if(this.state.password.trim()==''||this.state.password==null){
            errorOccured=true;
            this.setState({
                showEmptyPasswordInputError:true
            });
        }

        if(errorOccured==false){
            this.setState({
                loginLoader:true
            });

            axios.post('http://localhost:2000/authenticate',{loginid:this.state.loginID,password:this.state.password})
            .then((res)=>{
                console.log(res);
                if(res.data.hasError){
                    this.setState({
                        errorBoxText:res.data.message,
                        showErrorBox:true,
                        loginLoader:false
                    });
                }
                else{
                    localStorage.setItem("auth",res.data.accesstoken);
                    this.props.postAutherization(res.data.username);
                }
            }).catch((err)=>{
                this.setState({
                    errorBoxText:err.toString(),
                    showErrorBox:true,
                    loginLoader:false
                });
            });
        }
    }

    loginIDChange = (event) =>{
        this.setState({
            loginID:event.target.value,
            showEmptyLoginIDInputError:false
        });
    }

    passwordChange = (event) =>{
        this.setState({
            password:event.target.value,
            showEmptyPasswordInputError:false
        });
    }

    render(){
        if(this.state.slientLogin){
            return(
                <div className="App-header">
                <div className="container-flex loginbox">
                    <div className="d-flex align-items-center">
                        <strong>Loading...&nbsp; &nbsp;</strong>
                        <br/>
                        <div className="spinner-border ms-auto text-info Loading" role="status" aria-hidden="true"></div>
                    </div>
                </div>
            </div>
                );
        }
        else if(this.state.loginLoader){
            return(
                <div className="App-header">
                    <div className="container-flex loginbox">
                        <div className="d-flex align-items-center">
                            <strong>Logging In...&nbsp; &nbsp;</strong>
                            <br/>
                            <div className="spinner-border ms-auto text-info loginLoading" role="status" aria-hidden="true"></div>
                        </div>
                    </div>
                </div>
            );
        }
        else{
            return(
                <div className="App-header">
                    <div className="container-flex loginbox">
                        <div className='row loginText'>
                            <h4>Login</h4>
                        </div>
                        <br/>
                        <div className='row'>
                            <h6>Login ID</h6>
                            <div>
                                <div className='input-group'>
                                    <input id="loginId" value={this.state.loginID} onChange={this.loginIDChange} type="text" className={this.state.showEmptyLoginIDInputError?'form-control loginInput inputErrorOutline':'form-control loginInput'} placeholder='Enter your login ID' />
                                </div>
                                {this.state.showEmptyLoginIDInputError?<span className="form-label inputErrorText" for="loginId">Please Enter Login ID</span>:''}
                            </div>
                        </div>        
                        <div className='row passwordInputSpace'>
                            <h6>Password</h6>
                            <div>
                                <div className='input-group'>
                                    <input id="password" value={this.state.password} onChange={this.passwordChange} type="password" className={this.state.showEmptyPasswordInputError?'form-control loginInput inputErrorOutline':'form-control loginInput'} placeholder='Enter your password' />
                                </div>
                                {this.state.showEmptyPasswordInputError?<span className="form-label inputErrorText" for="password">Please Enter Password</span>:''}
                            </div>
                        </div>
                        {this.state.showErrorBox?<><br/><div className='alert alert-danger errorMsg'>{this.state.errorBoxText}</div></>:''}
                        <br/>
                        <div className='row'>
                            <button type="button" onClick={this.performLogin} className="btn btn-info loginBtn">LOGIN</button>            
                        </div>
                    </div>
                </div>
            );
        }
    }
}