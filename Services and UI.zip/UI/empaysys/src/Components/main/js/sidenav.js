import React from "react";
import "../css/sidenav.css";

export default class SideNav extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="sideNavBar">
                <h4 className="companyname">EMPAYSYS</h4>
                <ul className="MainMenu">
                    <li className={this.props.selecteddisplayid==0?"MainMenuMainList MainMenuMainListSelected":"MainMenuMainList"} onClick={()=>{this.props.changedisplay(0)}}>Dashboard</li>
                    <li className={this.props.selecteddisplayid==1?"MainMenuMainList MainMenuMainListSelected":"MainMenuMainList"} onClick={()=>{this.props.changedisplay(1)}}>Upload Timecard</li>
                    <li className={this.props.selecteddisplayid==2?"MainMenuMainList MainMenuMainListSelected":"MainMenuMainList"} onClick={()=>{this.props.changedisplay(2)}}>Payslip</li>
                    <li className={this.props.selecteddisplayid==3?"MainMenuMainList MainMenuMainListSelected":"MainMenuMainList"} onClick={()=>{this.props.changedisplay(3)}}>Salary Component</li>
                    <li className={this.props.selecteddisplayid==4?"MainMenuMainList MainMenuMainListSelected":"MainMenuMainList"} onClick={()=>{this.props.changedisplay(4)}}>Add Employee Salary</li>
                </ul>
            </div>
        );
    };
}