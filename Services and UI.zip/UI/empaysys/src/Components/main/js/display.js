import React from "react";
import "../css/display.css";
import TimecardDashboard from "../../timecard/js/dashboard";
import ProjectDetails from "../../admin/js/projectdetails";
import UploadAttendance from "../../timecard/js/uploadattendance";
import Upcomingholidays from "./upcomingholidays";
import Payslip from "../../payroll/js/payslip";
import Salary_Component from "../../payroll/js/salary_component";
import Add_Emp_Salary from "../../payroll/js/add_emp_salary";

export default class MainDisplay extends React.Component{
    constructor(props){
        super(props);
    }

    /*<UploadAttendance setunauthorizeduser={this.props.setunauthorizeduser}/>
                        <ProjectDetails setunauthorizeduser={this.props.setunauthorizeduser}/>
                        <TimecardDashboard setunauthorizeduser={this.props.setunauthorizeduser}/>*/
    render(){
        var displaytorender = '';
        switch(this.props.selecteddisplayid){
            case 0:
                displaytorender=<TimecardDashboard setunauthorizeduser={this.props.setunauthorizeduser}/>
                break;
            case 1:
                displaytorender=<UploadAttendance setunauthorizeduser={this.props.setunauthorizeduser}/>
                break;
            case 2:
                displaytorender=<TimecardDashboard setunauthorizeduser={this.props.setunauthorizeduser}/>
                break;
            case 3:
                displaytorender=<Salary_Component setunauthorizeduser={this.props.setunauthorizeduser}/>
                break;
            case 4:
                displaytorender=<TimecardDashboard setunauthorizeduser={this.props.setunauthorizeduser}/>
                break;
            default:
                displaytorender=<TimecardDashboard setunauthorizeduser={this.props.setunauthorizeduser}/>
                break;
        }
        return(
            <div className="mainDisplay">
                <div className="row selecteddisplayheader">
                    <h4>{this.props.selecteddisplay}</h4>
                </div>
                <div className="row">
                    <div className="col">
                        {
                            this.props.selecteddisplayid==0?
                            <TimecardDashboard setunauthorizeduser={this.props.setunauthorizeduser} />
                            :
                            this.props.selecteddisplayid==1?
                            <UploadAttendance setunauthorizeduser={this.props.setunauthorizeduser}/>
                            :
                            this.props.selecteddisplayid==2?
                            <Payslip setunauthorizeduser={this.props.setunauthorizeduser}/>
                            :
                            this.props.selecteddisplayid==3?
                            <Salary_Component setunauthorizeduser={this.props.setunauthorizeduser}/>
                            :
                            this.props.selecteddisplayid==4?
                            <Add_Emp_Salary setunauthorizeduser={this.props.setunauthorizeduser}/>
                            :
                            ''
                        }
                    </div>
                    <div className="col-3">
                        <Upcomingholidays/>
                    </div>
                </div>
            </div>
        );
    }
}