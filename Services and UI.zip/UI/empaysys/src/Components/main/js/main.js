import React from "react";
import TopNavBar from "./topnav";
import "../css/main.css";
import SideNav from "./sidenav";
import MainDisplay from "./display";

export default class Main extends React.Component{
    constructor(props){
        super(props);
        this.state={
            selectedDisplayID:0,
            selectedDisplayName:'Timecard Dashboard'
        };

        this.changeDisplay = this.changeDisplay.bind(this);
    }

    changeDisplay = (displayid)=>{
        
        var displayidtoset = 0;
        var displayname = '';
        switch(displayid){
            case 0:
                displayidtoset=displayid;
                displayname='Timecard Dashboard';
                break;
            case 1:
                displayidtoset=displayid;
                displayname='Upload Timecard';
                break;
            case 2:
                displayidtoset=displayid;
                displayname='Payslip';
                break;
            case 3:
                displayidtoset=displayid;
                displayname='Salary Component';
                break;
            case 4:
                displayidtoset=displayid;
                displayname='Release Payslip';
                break;
            default:
                displayidtoset=0;
                displayname='Timecard Dashboard'
                break;
        }

        this.setState({
            selectedDisplayID:displayidtoset,
            selectedDisplayName:displayname
        });
    }

    render(){
        return(
            <div className="container-fluid mainheader">
                <div>
                    <SideNav changedisplay={(changedisplayid)=>{this.changeDisplay(changedisplayid)}} selecteddisplayid={this.state.selectedDisplayID}/>
                </div>
                <div className="displaydiv">
                    <div>
                        <TopNavBar username={this.props.username}/>
                    </div>
                    <div>
                        <MainDisplay setunauthorizeduser={this.props.setunauthorizeduser} selecteddisplayid={this.state.selectedDisplayID} selecteddisplay={this.state.selectedDisplayName}/>
                    </div>
                </div>
            </div>
        );
    }
}