import React from "react";
import '../css/topnav.css';
import logo from '../images/logo.png';

export default class TopNavBar extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <div className="maincontainer">
                <div>
                    
                </div>
                <div className="username">
                    <span>{this.props.username}</span>
                </div>
            </div>
        );
    }
}