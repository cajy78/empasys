import React from "react"
import '../css/upcomingholiday.css'

export default class Upcomingholidays extends React.Component{
    constructor(props){
        super(props);
        this.state={
            date:'1st May 2022',
            holidayText:'Maharashtra Day'
        };
    }

    render(){
        return(
            <>
            <div class="card mainDisplayUpcoming">
                <h5 class="card-header">Upcoming Holiday</h5>
                <div class="card-body">
                    <h5 class="card-title">{this.state.date}</h5>
                    <p class="card-text">{this.state.holidayText}</p>
                </div>
            </div>
            </>
        );
    }
}