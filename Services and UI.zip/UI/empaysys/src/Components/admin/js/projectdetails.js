import React from "react";
import ExcelUpload from '../../common/js/excelupload.js'

export default class ProjectDetails extends React.Component{
    constructor(props){
        super(props);
    }

    render(){
        return(
            <ExcelUpload setunauthorizeduser={this.props.setunauthorizeduser} title="Upload Project Details" buttonText="Upload" uploadfunction="UploadProjectDetails"/>
        );
    }
}