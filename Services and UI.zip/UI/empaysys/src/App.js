import logo from './logo.svg';
import './App.css';
import Login from './Components/authentication/js/login.js';
import React from 'react';
import Main from './Components/main/js/main.js';

class App extends React.Component{
  constructor(prop){
    super(prop);
    this.state={
      isAuthHeaderAvaiable:false,
      showAppLoading:true,
      isAuthorized:false,
      username:""
    }
    this.checkIfAuthHeaderAvaiable = this.checkIfAuthHeaderAvaiable.bind(this);
    this.postAutherization = this.postAutherization.bind(this);
  }

  componentDidMount(){
    this.checkIfAuthHeaderAvaiable();
  }

  checkIfAuthHeaderAvaiable = ()=>{
    var header = localStorage.getItem("auth");
    if(header!=null||header!=''||header!=undefined){
      this.setState({
        isAuthHeaderAvaiable:true,
        showAppLoading:false
      });
    }
    else{
      this.setState({
        isAuthHeaderAvaiable:false,
        showAppLoading:false
      });
    }
  }

  postAutherization=(username)=>{
    this.setState({
      isAuthorized:true,
      username:username
    });
  }

  setunauthorizeduser=()=>{
    this.setState({
      isAuthorized:false,
      isAuthHeadAvailable:false
    });
  }

  render(){
    if(this.state.showAppLoading){
      return(
        <div className="App-header">
          <div className="container-flex loginbox">
            <div className="d-flex align-items-center">
              <strong>Loading...&nbsp; &nbsp;</strong>
              <br/>
              <div className="spinner-border ms-auto text-info Loading" role="status" aria-hidden="true"></div>
            </div>
          </div>
        </div>
      );
    }
    else if(!this.state.isAuthorized){
      return(
        <Login isAuthHeadAvailable={this.state.isAuthHeaderAvaiable} postAutherization={this.postAutherization}/>
      );
    }
    else{
      return(
        <Main setunauthorizeduser={this.setunauthorizeduser} username={this.state.username}/>
      );
    }
  };
}

export default App;
