const database_connect = require('./database_connect');
module.exports={
    select:async()=>{
        var query = "Select * from employees";
        return await database_connect.ExecuteQuery(query);
    }
}