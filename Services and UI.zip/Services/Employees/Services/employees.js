const employees_database = require("../database/database_employees");

module.exports = {
    getallemployees:async()=>{
        return await employees_database.select();
    }
}