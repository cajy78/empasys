const { default: axios } = require('axios');
const { response } = require('express');
var express = require('express');
const employees = require('./Services/employees');

const app = express();

app.use(express.json());


app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    //res.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
    res.setHeader("Access-Control-Allow-Headers", "*");
    next();
  });

  function validateToken(req,resp,next){
    axios.post('http://localhost:2000/validateToken',{},{
        headers:{
            "x-access-token":req.headers["x-access-token"]
        }
    }).then(result=>{
        if(result.data.hasError)
        {
            return resp.sendStatus(401).json(result);
        }
        req.body.userdetails = result.data.userdetails;
        console.log(req.body.userdetails);
        next();
    })
    .catch(e=>{
      console.log("hit error in validate token");
        console.log(e);
        return resp.sendStatus(500);
    });
  }

  app.post('/getemployees',validateToken,async(req,res)=>{
    try{
      var data = await employees.getallemployees();
      return res.json(data);
    }
    catch(err){
        console.log(err);
        res.statusCode=500;
        return res.json(err);
    }
  });

  app.listen(2003);