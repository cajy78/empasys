const database_projectdetails = require("../database/database_projectdetails");

module.exports = {

    insertbulkdata:async(data, userid)=>{
        var arrayobj = [];

        //convert the json result into array object because nodejs mysql require array object for insert
        for(var i in data){
            arrayobj.push([data [i].Name, 1, userid]);
        }
        return await database_projectdetails.insert(arrayobj);
    },

    getprojectdetails:async()=>{
        return await database_projectdetails.getprojectdetails();
    }

}