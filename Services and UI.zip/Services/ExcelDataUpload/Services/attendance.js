const database_attendanceupload = require("../database/database_attendanceupload");
const projectdetail = require("./projectdetails");

module.exports = {

    insertattedancebulkdata:async(data, userid)=>{
        //get attendance statues and projects to retrive the IDs 
            //as the backend of the attendance table only requires the attendance and project id
            var attendanceStatues =  await database_attendanceupload.getattendancestatues();
            var projectdetails = await projectdetail.getprojectdetails();

            //convert the json data to array object as mysql nodejs lib only takes in 
            //array objects to insert bulk data
            var arrayobj = [];
            for(var i in data){
                console.log(data[i]);
                console.log("for project "+data[i].projectname);
                console.log("for status "+data[i].attendanceStatus);

                var attendanceStatusID=0;
                var searchText = "";

                //we do this because the value of overtime submitted by the user is in terms of hours
                //and the attendance status only contains values such as P, L, EH, Overtime, etc and not hours
                //so when overtime item is selected we set the status id to project id (which is overtime)
                if(data[i].projectname.toUpperCase()=='OVERTIME'){
                    //if its overtime then status id should be of project name
                    searchText = "OT";
                }
                else{
                    //else search text should be attendance status
                    var searchText = data[i].attendanceStatus.toUpperCase();
                }
                
                attendanceStatues.forEach(element => {
                    if(element.Name.toUpperCase()==searchText){
                        attendanceStatusID=element.ID;
                    }
                });

                if(attendanceStatusID==0){
                    throw new Error("Error: Attendance Status - "+data[i].attendanceStatus+" is unavailable. Kindly add the attendance status")
                }
                console.log(attendanceStatusID);

                //for each line item in the json data get the project ID
                var projectid = 0
                projectdetails.forEach(element=>{
                    if(element.Name.toUpperCase()==data[i].projectname.toUpperCase()){
                        projectid = element.ID;
                    }
                });
                
                if(projectid==0){
                    throw new Error("Error: Project Name - "+data[i].projectname+" is unavailable. Kindly add the project")
                }

                console.log(projectid);

                //if the status is not present or overtime put the working hours as 0
                var workinghours = 0;
                if(searchText=='OT'){
                    //overtime working hours will come from the excel sheet
                    workinghours=data[i].attendanceStatus;
                }
                else if(searchText=='P'){
                    workinghours=9;
                }

                arrayobj.push([data [i].empnumber, userid, projectid, attendanceStatusID, new Date(data[i].date).toISOString().slice(0, 10), workinghours]);
            }
            console.log(arrayobj);
            return await database_attendanceupload.insert(arrayobj);
    },

    getattendance:async(startDate,endDate,userid)=>{
        var arrayobj=[userid,startDate,endDate];
        return await database_attendanceupload.getattendance(arrayobj);

    }

}