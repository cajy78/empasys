const { default: axios } = require('axios');
const { response } = require('express');
var express = require('express');
const attendance = require('./Services/attendance');
const projectdetails = require('./Services/projectdetails');

const app = express();

app.use(express.json());


app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    //res.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
    res.setHeader("Access-Control-Allow-Headers", "*");
    next();
  });

  function validateToken(req,resp,next){
    axios.post('http://localhost:2000/validateToken',{},{
        headers:{
            "x-access-token":req.headers["x-access-token"]
        }
    }).then(result=>{
        if(result.data.hasError)
        {
            return resp.sendStatus(401).json(result);
        }
        req.body.userdetails = result.data.userdetails;
        console.log(req.body.userdetails);
        next();
    })
    .catch(e=>{
      console.log("hit error in validate token");
        console.log(e);
        return resp.sendStatus(500);
    });
  }


  app.post('/bulkuploadprojectdetails',validateToken,(req,res)=>{
    projectdetails.insertbulkdata(req.body.data,1).then((data)=>{
        res.sendStatus(200);
    }).catch((err)=>{
        res.sendStatus(500).send(err);
    });
  });

  app.post('/bulkuploadattendance',validateToken,async(req,res)=>{
      try{
        await attendance.insertattedancebulkdata(req.body.data,req.body.userdetails.ID);
        return res.sendStatus(200);
      }
      catch(err){
        console.log(err);
        res.statusCode=500;
        return res.send(err);
      }
  });

  app.post('/getmyattendanceforcalenderview',validateToken,async(req,res)=>{
    try{
      var data = await attendance.getattendance(req.body.data.startDate,req.body.data.endDate,req.body.userdetails.ID);
      var returnarray=[];
      
      data.forEach(element => {
        var attendanceStatus = element.AttendanceStatus;

        //if the project is overtime then show the OI Hours
        if(attendanceStatus=="Overtime"){
          attendanceStatus=element.Hours +" Hours";
        }

        var jsondata = {
          "event":element.ProjectName + ": "+attendanceStatus,
          "start":element.Date,
          "status": attendanceStatus,
          "project":element.ProjectName,
          "hours":element.Hours
        }

        returnarray.push(jsondata);

      });

      console.log(returnarray);

      return res.json(returnarray);
    }
    catch(err){
      console.log(err);
      res.statusCode=500;
      return res.send(err);
    }
});

  app.listen(2001);