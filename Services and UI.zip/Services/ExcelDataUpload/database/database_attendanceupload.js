const res = require('express/lib/response');
const database_connect = require('./database_connect');
var mysql = require('mysql2');
module.exports={
    insert:async(values)=>{
        var query = "Insert into timecard(empid, createdby, projectid, attendancestatusid, date, Hours) values ?";
        return await database_connect.ExecuteQuery(query,values);
    },

    getattendancestatues:async()=>{
        var query = "Select * from attendance_status";
        return await database_connect.ExecuteQuery(query);
    },

    getattendance:async(values)=>{
        var query = "Select * from vw_timecard where empid="+mysql.escape(values[0])+
        " and date>="+mysql.escape(values[1])+" and date<="+mysql.escape(values[2]);
        return await database_connect.ExecuteQuery(query);
    }
}