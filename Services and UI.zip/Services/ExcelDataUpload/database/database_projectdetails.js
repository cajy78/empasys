const database_connect = require('./database_connect.js');
module.exports={
    insert:async(values)=>{
        var query = "Insert into projects(Name, isActive,CreatedBy) values ?";
        return await database_connect.ExecuteQuery(query,values);
    },

    getprojectdetails:async()=>{
        var query = "Select * from projects";
        return await database_connect.ExecuteQuery(query);
    }
}