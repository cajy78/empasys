const database_connect = require('./database_connect');

module.exports.CreateLogin = (logintypeid, domainid, name, username, email, isactive, iscurrent, createdby, modifiedBy) =>{
    return new Promise((resolve,reject)=>{
        var query = "Insert into login(LoginTypeID, DomainID, Name, UserName, Email, isActive, isCurrent, CreatedBy, ModifiedBy) values (?,?,?,?,?,?,?,?,?)";
        database_connect.ExecuteQuery(query,[logintypeid, domainid, name, username, email, isactive, iscurrent, createdby, modifiedBy])
        .then((result)=>{
            resolve(result);
        })
        .catch((err)=>{
            console.log(err);
            reject(err);
        });
    });
}

module.exports.CreatePasswordPolicy = (domainid,expirydays,iscurrent,createdby) =>{
    var query = "Insert into password_policy(domainid,expirydays,iscurrent,createdby) values (?,?,?,?)";
    return ExecuteQuery(query,[domainid,expirydays,iscurrent,createdby]);
}

module.exports.CreateLoginType = (loginTypeName, createdby) =>{
    var query = "Insert into login_type_definition(Name, CreatedBy) values (?,?)";
    return database_connect.ExecuteQuery(query,[loginTypeName, createdby]);
}

module.exports.GetDomainPasswordPolicy = (domainid)=>{
    return new Promise((resolve,reject)=>{
        var query = "Select * from password_policy where domainid = ? and iscurrent=1";
        database_connect.ExecuteQuery(query,[domainid]).then((res)=>{
            resolve(res);
        }).catch((err)=>{
            reject(err);
        });
    });
}

module.exports.CreatePassword = (loginid,password,isexpired,iscurrent,enablereset,createdby,passwordpolicyid,salt)=>{
    return new Promise((resolve,reject)=>{
        var query = "Insert into login_password(loginid,passwordtext,isexpired,iscurrent,enablereset,createdby,passwordpolicyid,salt) values(?,?,?,?,?,?,?,?)";
        database_connect.ExecuteQuery(query,[loginid,password,isexpired,iscurrent,enablereset,createdby,passwordpolicyid,salt]).then((res)=>{
            resolve(res);
        }).catch((err)=>{
            console.log(err);
            reject(err);
        });
    });
}

module.exports.Authenticate = (loginid)=>{
    return new Promise((resolve,reject)=>{
        var query = "Select * from login_password where loginid=?";
        database_connect.ExecuteQuery(query,[loginid]).then((res)=>{
            resolve(res);
        }).catch((err)=>{
            console.log(err);
            reject(err);
        });
    });
}

module.exports.GetUserDetails = (loginid)=>{
    return new Promise((resolve,reject)=>{
        var query = "Select * from login where id=?";
        database_connect.ExecuteQuery(query,[loginid]).then((res)=>{
            resolve(res);
        }).catch((err)=>{
            console.log(err);
            reject(err);
        });
    });
}