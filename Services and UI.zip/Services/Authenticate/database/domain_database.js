const database_connect = require('./database_connect');

module.exports.CreateDomain = (domain, ClientID, issubdomain, createdby) =>{
    var query = "Insert into domain(ClientID, Name, isSubDomain, CreatedBy) values (?,?,?,?)";
    database_connect.ExecuteQuery(query,[domain, ClientID, issubdomain, createdby]);
}
