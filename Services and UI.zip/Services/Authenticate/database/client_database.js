const database_connect = require('./database_connect');

module.exports.CreateClient = (clientName, createdby, isactive, iscurrent) =>{
    var query = "Insert into client(Name, CreatedBy, isActive, isCurrent) values (?,?,?,?)";
    database_connect.ExecuteQuery(query,[clientName, createdby, isactive, iscurrent]);
}