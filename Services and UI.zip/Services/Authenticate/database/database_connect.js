var mysql = require('mysql2');
const dotenv = require('dotenv');

dotenv.config();
var con = mysql.createConnection({
    host: process.env.dbhost,
    user: process.env.dbuser,
    password: process.env.dbpassword,
    database: process.env.dbdatabase
});

module.exports.ExecuteQuery = (query, values)=>{
    return new Promise((resolve,reject)=>{
        con.query(query,values,(err, res)=>{
            if(err){
                console.log(err);
                return reject(err);
            }
            else{
                resolve(res);
            }
        });
    });
    con.connect((err)=>{
        if(err){
            return err;
        }
        else{
            con.query(query,values,(err, res)=>{
                if(err){
                    return err;
                }
                else{
                    console.log("exeq");
                    console.log(res);
                    return res;
                }
            });
        }
    });
}
