const jwt = require("jsonwebtoken");
const dotenv = require('dotenv');

dotenv.config();

module.exports = {

    createtoken:(datapayload)=>{
        var token = jwt.sign(datapayload,process.env.jwtsecretetoken,{
            expiresIn:"600s"
        });
        return token;
    },

    validatetoken:(token)=>{
        var data={
            datapayload:"",
            error:"",
            hasError:false
        }        
        try{
            var decoded = jwt.verify(token,process.env.jwtsecretetoken);
            data.datapayload=decoded;
        }
        catch(e){
            data.hasError=true;
            data.error=e;
        }

        return data;
    }
    
}