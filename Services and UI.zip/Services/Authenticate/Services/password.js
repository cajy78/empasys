const bcrypt = require("bcrypt");

module.exports = {

    GetHashedPassword:async(password)=>{
        var salt = await bcrypt.genSalt(10);
        var hashedpassword = await bcrypt.hash(password, salt);
        return hashedpassword;
    },

    ValidatePassword: async(enteredpassword, storedpassword)=>{
        const validPassword = await bcrypt.compare(enteredpassword, storedpassword);
        return validPassword;
    }
}