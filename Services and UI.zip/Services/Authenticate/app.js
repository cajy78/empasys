const { response } = require('express');
var express = require('express');
const login_database = require('./database/login_database');
const jwttoken = require('./Services/jwttoken');
const jwtservice = require("./Services/jwttoken");
const passwordservice = require('./Services/password');

const app = express();

app.use(express.json());

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    //res.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
    res.setHeader("Access-Control-Allow-Headers", "*");
    next();
  });

//app.use(cors());

app.post('/createuserlogin', (req, res)=>{
    login_database.GetDomainPasswordPolicy(req.body.domainid).then((result)=>{
        login_database.CreateLogin(result.ID,req.body.domainid,req.body.name,req.body.username,req.body.email,1,1,'owner','owner')
        .then((innerresult)=>{
            res.statusCode=200;
            res.json(innerresult);
        })
        .catch((err)=>{
            console.log(err);
            res.statusCode=500;
            res.json(err);
        });
    }).catch((err)=>{
        console.log(err);
        res.json(err);
    });
 });

 app.post('/createpassword',async(req,res)=>{
     var hashedpassword = await passwordservice.GetHashedPassword(req.body.password);// await bcrypt.hash(req.body.password, salt);
    login_database.GetDomainPasswordPolicy(req.body.domainid).then((result)=>{
        login_database.CreatePassword(1,hashedpassword,0,1,0,'owner',1,'')
        .then((innerresult)=>{
            res.statusCode=200;
            res.json(innerresult);
        })
        .catch((err)=>{
            console.log(err);
            res.statusCode=500;
            res.json(err);
        });
    })
    .catch((err)=>{
        console.log(err);
        res.statusCode=500;
        res.json(err);
    });
 });

 app.post('/authenticate',async(req,res)=>{    
     var responsedata={
        accesstoken: "", 
        hasError: false, 
        message:"",
        username:''
     };
    login_database.Authenticate(req.body.loginid)
    .then(async(innerresult)=>{
        var user = innerresult[0];
        console.log(user);
        const validPassword = await passwordservice.ValidatePassword(req.body.password,user.PasswordText); //bcrypt.compare(req.body.password, user.PasswordText);
        if(validPassword){
            login_database.GetUserDetails(user.LoginID).then((userdetailsdata)=>{
                var token = jwtservice.createtoken(userdetailsdata[0]);
                responsedata.accesstoken=token;
                responsedata.message="authenticated";
                responsedata.username=userdetailsdata[0].Name;
                res.statusCode=200;
                res.json(responsedata);
            })
            .catch((err)=>{
                console.log(err);
                responsedata.hasError=true;
                responsedata.message="Login Successful. Failed to obtain user data: "+err;
                res.statusCode=500;
                res.json(responsedata);
            });
        }
        else{
            responsedata.hasError=true;
            responsedata.message="Invalid Credentials";
            res.statusCode=200;
            res.json(responsedata);
        }
    })
    .catch((err)=>{
        console.log(err);
        res.statusCode=500;
        res.json(err);
    });
});

app.post('/validateToken',(req,res)=>{
    var responsedata={
        isTokenValid: false, 
        hasError: false, 
        message:"",
        username:'',
        userdetails:''
     };

     const token = req.headers["x-access-token"];
     if(!token){
        responsedata.hasError=true;
        responsedata.message="No Auth Header Found";
        res.statusCode==200;
        res.json(responsedata);
     }
     else{
        var data = jwttoken.validatetoken(token);

        console.log(data);

        responsedata.hasError=data.hasError;
        responsedata.isTokenValid=!data.hasError;
        responsedata.message=data.error;
        responsedata.username=data.datapayload.Name;
        responsedata.userdetails=data.datapayload;
        res.statusCode==200;
        res.json(responsedata);
     }
});

app.listen(2000);
