const database_connect = require('./database_connect');
module.exports={
    insert:async(values)=>{
        var query ="insert into salary_component(Name,isActive,CreatedBy,displayInPayslip,displayIfZero,showInAddition,showInDeduction) values ?";
        return await database_connect.ExecuteQuery(query,[values]);
    },

    select:async(values)=>{
        var query = "Select * from vw_employee_salary_package where isCurrent=?";
        return await database_connect.ExecuteQuery(query,[values]);
    }
}