const database_connect = require('./database_connect');
module.exports={
    insert:async(values)=>{
        var query ="insert into salary_component(Name,isActive,CreatedBy,displayInPayslip,displayIfZero,showInAddition,showInDeduction) values ?";
        return await database_connect.ExecuteQuery(query,[values]);
    },

    select:async()=>{
        var query = "Select * from salary_component";
        return await database_connect.ExecuteQuery(query);
    }
}