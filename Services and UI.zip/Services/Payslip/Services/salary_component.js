const database_salary_component = require("../database/database_salary_component");

module.exports = {
    insert:async(data,userid)=>{
        console.log(data);
        var arrayobj=[];
        for(var i in data){
            arrayobj.push(data[i].name, 1, userid, data[i].displayInPayslip, data[i].displayIfZero, data[i].showInAddition, data[i].showInDeduction);
        }
        return await database_salary_component.insert(arrayobj);
    },

    GetAllSalaryComponent:async()=>{
        return await database_salary_component.select();
    }
}