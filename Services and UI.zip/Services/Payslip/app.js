const { default: axios } = require('axios');
const { response } = require('express');
var express = require('express');
const employee_package = require('./Services/employee_package');
const salary_component = require('./Services/salary_component');

const app = express();

app.use(express.json());


app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    //res.setHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");
    res.setHeader("Access-Control-Allow-Headers", "*");
    next();
  });

  function validateToken(req,resp,next){
    axios.post('http://localhost:2000/validateToken',{},{
        headers:{
            "x-access-token":req.headers["x-access-token"]
        }
    }).then(result=>{
        if(result.data.hasError)
        {
            return resp.sendStatus(401).json(result);
        }
        req.body.userdetails = result.data.userdetails;
        console.log(req.body.userdetails);
        next();
    })
    .catch(e=>{
      console.log("hit error in validate token");
        console.log(e);
        return resp.sendStatus(500);
    });
  }

  app.post('/getsalarycomponent',validateToken,async(req,res)=>{
    try{
      var data = await salary_component.GetAllSalaryComponent();
      return res.json(data);
    }
    catch(err){
      console.log(err);
      res.statusCode=500;
      return res.send(err);
    }
});

  app.post('/addsalarycomponent',validateToken,async(req,res)=>{
      try{
        console.log(req.body.data);
        await salary_component.insert(req.body.data,req.body.userdetails.ID);
        return res.send(200);
      }
      catch(err){
        console.log(err);
        res.statusCode=500;
        return res.send(err);
      }
  });

  app.post('/getemployeepackage',validateToken,async(req,res)=>{
    try{
      console.log(req.body.data);
      var data = await employee_package.getemployeepackage(req.body.data.empid);
      return res.json(data);
    }
    catch(err){
      console.log(err);
      res.statusCode=500;
      return res.send(err);
    }
});

  app.listen(2002);